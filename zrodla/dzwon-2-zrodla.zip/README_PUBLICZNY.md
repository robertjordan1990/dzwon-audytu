# Dzwon — część 2 — pakiet publiczny

Status: pakiet publiczny minimalny.

Zawartość:
- dzwon-2.pdf
- README_PUBLICZNY.md
- SHA256SUMS.txt

Uwaga:
Jeżeli przed publikacją zostanie przygotowana pełniejsza publiczna paczka źródłowa, należy zastąpić ten ZIP wersją rozszerzoną i przeliczyć SHA-256.

Ten pakiet nie zawiera materiałów prywatnych, roboczych rozmów, nagłówków poczty ani danych RED.
